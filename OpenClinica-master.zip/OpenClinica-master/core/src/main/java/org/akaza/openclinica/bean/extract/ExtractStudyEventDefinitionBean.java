/*
 * OpenClinica is distributed under the
 * GNU Lesser General Public License (GNU LGPL).

 * For details see: http://www.openclinica.org/license
 * copyright 2003-2005 Akaza Research
 *
 * Created on Jul 11, 2005
 */
package org.akaza.openclinica.bean.extract;

import org.akaza.openclinica.bean.managestudy.StudyEventDefinitionBean;

/**
 * @author ssachs
 */
public class ExtractStudyEventDefinitionBean extends StudyEventDefinitionBean {

}
