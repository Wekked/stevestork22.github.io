package org.akaza.openclinica.dao.cache;

public class StringStatement <PreparedStatement> {

}
