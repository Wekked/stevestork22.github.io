package org.akaza.openclinica.bean.rule;

public interface EditCheckInterface {

    public boolean check();

}
