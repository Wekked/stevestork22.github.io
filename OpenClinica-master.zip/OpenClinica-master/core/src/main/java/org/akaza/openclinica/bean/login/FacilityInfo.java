package org.akaza.openclinica.bean.login;

/**
 * Created by yogi on 8/9/17.
 */
public class FacilityInfo {
    String facilityCity;
    String facilityState;
    String facilityZip;
    String facilityCountry;
    String facilityContact;
    String facilityEmail;
    String facilityPhone;

    public String getFacilityCity() {
        return facilityCity;
    }

    public void setFacilityCity(String facilityCity) {
        this.facilityCity = facilityCity;
    }

    public String getFacilityState() {
        return facilityState;
    }

    public void setFacilityState(String facilityState) {
        this.facilityState = facilityState;
    }

    public String getFacilityZip() {
        return facilityZip;
    }

    public void setFacilityZip(String facilityZip) {
        this.facilityZip = facilityZip;
    }

    public String getFacilityCountry() {
        return facilityCountry;
    }

    public void setFacilityCountry(String facilityCountry) {
        this.facilityCountry = facilityCountry;
    }

    public String getFacilityContact() {
        return facilityContact;
    }

    public void setFacilityContact(String facilityContact) {
        this.facilityContact = facilityContact;
    }

    public String getFacilityEmail() {
        return facilityEmail;
    }

    public void setFacilityEmail(String facilityEmail) {
        this.facilityEmail = facilityEmail;
    }

    public String getFacilityPhone() {
        return facilityPhone;
    }

    public void setFacilityPhone(String facilityPhone) {
        this.facilityPhone = facilityPhone;
    }
}
