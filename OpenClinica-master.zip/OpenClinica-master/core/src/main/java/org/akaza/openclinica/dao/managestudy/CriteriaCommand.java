package org.akaza.openclinica.dao.managestudy;

public interface CriteriaCommand {

    public String execute(String criteria);

}
